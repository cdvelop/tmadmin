// admin_dashboard.js

document.addEventListener("DOMContentLoaded", () => {
    // Gestión de Usuarios
    const createUserForm = document.getElementById("create-user-form");
    if (createUserForm) {
        createUserForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const fullName = document.getElementById("full-name").value.trim();
            const run = document.getElementById("run").value.trim();
            const userType = document.getElementById("user-type").value;
            const tempPassword = document.getElementById("temp-password").value.trim();

            if (!fullName || !run || !userType || !tempPassword) {
                alert("Por favor, completa todos los campos.");
                return;
            }

            // Simulación: agregar a la tabla de usuarios
            const userTableBody = document.querySelector("#user-management table tbody");
            const newRow = document.createElement("tr");

            newRow.innerHTML = `
                <td>${fullName}</td>
                <td>${userType}</td>
                <td><button class="edit">Editar</button> <button class="delete">Eliminar</button></td>
            `;

            userTableBody.appendChild(newRow);

            alert("Usuario creado exitosamente.");
            createUserForm.reset();
        });
    }

    // Validación de Pagos
    const paymentTableBody = document.querySelector("#payment-validation table tbody");
    if (paymentTableBody) {
        paymentTableBody.addEventListener("click", (e) => {
            if (e.target.tagName === "BUTTON" && e.target.classList.contains("validate")) {
                const row = e.target.closest("tr");
                const statusCell = row.querySelector("td:nth-child(5)");
                statusCell.textContent = "Validado";
                e.target.remove();
                alert("Pago validado exitosamente.");
            }
        });
    }

    // Gestión de Torneos
    const createTournamentForm = document.getElementById("create-tournament-form");
    if (createTournamentForm) {
        createTournamentForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const tournamentName = document.getElementById("tournament-name").value.trim();
            const categories = document.getElementById("categories").value.trim();
            const entryFee = document.getElementById("entry-fee").value.trim();
            const dates = document.getElementById("dates").value.trim();
            const location = document.getElementById("location").value.trim();

            if (!tournamentName || !categories || !entryFee || !dates || !location) {
                alert("Por favor, completa todos los campos.");
                return;
            }

            // Simulación: agregar a la tabla de torneos
            const tournamentTableBody = document.querySelector("#tournament-management table tbody");
            const newRow = document.createElement("tr");

            newRow.innerHTML = `
                <td>${tournamentName}</td>
                <td>${categories}</td>
                <td>${entryFee}</td>
                <td>${dates}</td>
                <td>${location}</td>
                <td><button class="edit">Editar</button> <button class="delete">Eliminar</button></td>
            `;

            tournamentTableBody.appendChild(newRow);

            alert("Torneo creado exitosamente.");
            createTournamentForm.reset();
        });
    }

    // Gestión de Noticias
    const createNewsForm = document.getElementById("create-news-form");
    const newsList = document.getElementById("news-list");
    if (createNewsForm && newsList) {
        createNewsForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const newsTitle = document.getElementById("news-title").value.trim();
            const newsContent = document.getElementById("news-content").value.trim();
            const newsDate = document.getElementById("news-date").value.trim();

            if (!newsTitle || !newsContent || !newsDate) {
                alert("Por favor, completa todos los campos.");
                return;
            }

            // Simulación: agregar a la lista de noticias
            const newsItem = document.createElement("li");
            newsItem.textContent = `${newsDate} - ${newsTitle}: ${newsContent}`;
            newsList.appendChild(newsItem);

            alert("Noticia creada exitosamente.");
            createNewsForm.reset();
        });
    }
});
