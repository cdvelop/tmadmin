// user_dashboard.js

document.addEventListener("DOMContentLoaded", () => {
    // Ficha Personal Validation
    const personalInfoForm = document.getElementById("personal-info-form");
    if (personalInfoForm) {
        personalInfoForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const fields = ["full-name", "run", "birth-date", "gender", "email", "phone"];
            let valid = true;

            fields.forEach(field => {
                const input = document.getElementById(field);
                if (!input.value.trim()) {
                    alert(`El campo ${field} es obligatorio.`);
                    valid = false;
                }
            });

            if (valid) {
                alert("Información guardada exitosamente.");
            }
        });
    }

    // Highlight Pending Payments
    const paymentHistoryTable = document.querySelector("#payment-history table tbody");
    if (paymentHistoryTable) {
        // Example Data
        const payments = [
            { date: "2024-01-15", concept: "Membresía", amount: "$10,000", method: "Transferencia", status: "Validado" },
            { date: "2024-02-10", concept: "Inscripción", amount: "$5,000", method: "Efectivo", status: "Pendiente" }
        ];

        payments.forEach(payment => {
            const row = document.createElement("tr");

            Object.values(payment).forEach(value => {
                const cell = document.createElement("td");
                cell.textContent = value;
                row.appendChild(cell);
            });

            if (payment.status === "Pendiente") {
                row.style.color = "red";
            }

            paymentHistoryTable.appendChild(row);
        });
    }

    // Tournament Registration
    const tournamentForm = document.getElementById("tournament-form");
    if (tournamentForm) {
        tournamentForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const tournament = document.getElementById("tournament").value;
            const category = document.getElementById("category").value;

            if (!tournament || !category) {
                alert("Seleccione un torneo y una categoría.");
            } else {
                alert("Inscripción confirmada para el torneo.");
            }
        });
    }

    // Load News Dynamically
    const newsList = document.getElementById("news-list");
    if (newsList) {
        // Example Data
        const news = [
            "Evento de torneo este fin de semana.",
            "Nueva membresía disponible para inscripciones.",
            "Actualización de fechas de torneos regionales."
        ];

        news.forEach(item => {
            const li = document.createElement("li");
            li.textContent = item;
            newsList.appendChild(li);
        });
    }
});
