// auth.js

document.addEventListener("DOMContentLoaded", () => {
    // Definir usuarios de prueba
    const testUsers = {
        "admin": "admin123",
        "jugador": "jugador123",
        "apoderado": "apoderado123"
    };

    // Login form validation
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value.trim();
            const loginMessage = document.getElementById("login-message");

            if (!username || !password) {
                loginMessage.textContent = "Por favor, completa todos los campos.";
                loginMessage.style.color = "red";
                return;
            }

            if (testUsers[username] && testUsers[username] === password) {
                loginMessage.textContent = "Inicio de sesi���n exitoso.";
                loginMessage.style.color = "green";
                // Redirigir seg���n el rol
                if (username === "admin") {
                    window.location.href = "admin_dashboard.html";
                } else {
                    window.location.href = "user_dashboard.html";
                }
            } else {
                loginMessage.textContent = "Usuario o contrase���a incorrectos.";
                loginMessage.style.color = "red";
            }
        });
    }

    // Change password form validation
    const changePasswordForm = document.getElementById("change-password-form");
    if (changePasswordForm) {
        changePasswordForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const currentPassword = document.getElementById("current-password").value.trim();
            const newPassword = document.getElementById("new-password").value.trim();
            const confirmPassword = document.getElementById("confirm-password").value.trim();
            const passwordMessage = document.getElementById("password-message");

            if (!currentPassword || !newPassword || !confirmPassword) {
                passwordMessage.textContent = "Por favor, completa todos los campos.";
                passwordMessage.style.color = "red";
                return;
            }

            if (newPassword.length < 8) {
                passwordMessage.textContent = "La nueva contrase���a debe tener al menos 8 caracteres.";
                passwordMessage.style.color = "red";
                return;
            }

            if (newPassword !== confirmPassword) {
                passwordMessage.textContent = "Las contrase���as no coinciden.";
                passwordMessage.style.color = "red";
                return;
            }

            // Simulate password change success (replace with actual logic)
            passwordMessage.textContent = "Contrase���a cambiada exitosamente.";
            passwordMessage.style.color = "green";
        });
    }
});
